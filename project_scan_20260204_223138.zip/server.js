﻿const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 5001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Route for health check
app.get("/api/health", (req, res) => {
    res.json({
        status: "healthy",
        timestamp: new Date().toISOString(),
        message: "David & Farid Tax Refund System",
        version: "1.0.0"
    });
});

// Route for stats (temporary)
app.get("/api/stats", (req, res) => {
    res.json({
        total_simple: 10,
        total_detailed: 5,
        total_submissions: 15,
        total_refund: 45000,
        total_commission: 4500
    });
});

// Serve HTML pages
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/form25.html", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "form25.html"));
});

app.get("/dashboard.html", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "dashboard.html"));
});

app.get("/admin.html", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "admin.html"));
});

// Handle form submissions (simple version)
app.post("/api/submit", (req, res) => {
    console.log("Form submission received:", req.body);
    res.json({
        success: true,
        message: "Form submitted successfully!",
        submission_id: "SUB-" + Date.now(),
        estimated_refund: 2500 + Math.floor(Math.random() * 5000),
        commission: 250
    });
});

// Start server
app.listen(PORT, () => {
    console.log("\n" + "=".repeat(50));
    console.log("🚀 DAVID & FARID TAX REFUND SYSTEM");
    console.log("=".repeat(50));
    console.log(`🌐 Server running on: http://localhost:${PORT}`);
    console.log(`📱 Main page:        http://localhost:${PORT}`);
    console.log(`📋 Form 25:          http://localhost:${PORT}/form25.html`);
    console.log(`📊 Dashboard:        http://localhost:${PORT}/dashboard.html`);
    console.log(`🔐 Admin:            http://localhost:${PORT}/admin.html`);
    console.log(`🔧 API Health:       http://localhost:${PORT}/api/health`);
    console.log("=".repeat(50));
    console.log("✅ Ready for ngrok connection!");
    console.log("=".repeat(50) + "\n");
});

